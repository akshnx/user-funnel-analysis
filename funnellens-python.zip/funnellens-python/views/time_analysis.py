"""Time Analysis – time-to-purchase histogram and session-length box plot."""
import numpy as np
import plotly.graph_objects as go
import streamlit as st

from services import metrics as m
from ui import components as c
from ui import theme as t
from ui.layout import get_ctx, require_data

ctx = get_ctx()
if not require_data(ctx):
    st.stop()

cur = ctx.cur
with st.spinner("Crunching sessions…"):
    ttp = m.time_to_purchase(cur)
    sess = m.session_lengths(cur)

k1, k2, k3 = st.columns(3, gap="medium")
stats = [
    (k1, "Median time to purchase", f"{ttp.median():.1f}" if len(ttp) else "—", "min from first view"),
    (k2, "Avg. session length", f"{sess['minutes'].mean():.1f}" if len(sess) else "—", "minutes"),
    (k3, "Avg. order value", c.fmt_money(m.aov(cur)), "per purchasing session"),
]
for col, label, val, sub in stats:
    with col, c.card(f"k-{label[:8]}"):
        c.show(f'<div class="fl-label">{label}</div><div class="fl-mid" style="margin-top:8px">'
               f'<span class="countup">{val}</span></div><div class="fl-card-sub">{sub}</div>')

st.write("")
left, right = st.columns(2, gap="medium")

with left, c.card("hist"):
    c.show(c.card_head("Time to purchase", "Minutes from first view to purchase, same session"))
    if len(ttp):
        clip = ttp.clip(upper=np.percentile(ttp, 97))
        fig = go.Figure(go.Histogram(x=clip, nbinsx=40, marker=dict(
            color=t.ICE, opacity=0.85, cornerradius=4, line=dict(width=0)),
            hovertemplate="%{x} min · %{y:,} sessions<extra></extra>"))
        fig.add_vline(x=ttp.median(), line=dict(color=t.CORAL, width=2, dash="dot"),
                      annotation=dict(text=f"median {ttp.median():.1f}m", font=dict(color=t.CORAL)))
        t.style_fig(fig, height=320, hovermode="closest", bargap=0.08,
                    xaxis=dict(title="Minutes"), yaxis=dict(title="Sessions"))
        st.plotly_chart(fig, theme=None, config=t.PLOTLY_CONFIG)
    else:
        c.empty_state("No purchases", "There are no purchase sessions in this selection.", "⏱")

with right, c.card("box"):
    c.show(c.card_head("Session length by outcome", "Do buyers browse longer?"))
    s = sess[sess["minutes"] > 0]
    fig = go.Figure()
    for name, color in [("No purchase", t.PREV_LINE), ("Purchased", t.MINT)]:
        v = s.loc[s["outcome"] == name, "minutes"]
        if len(v) > 4000:
            v = v.sample(4000, random_state=1)
        fig.add_box(y=v, name=name, marker=dict(color=color, size=3), line=dict(color=color),
                    fillcolor="rgba(52,211,153,0.12)" if name == "Purchased" else "rgba(255,255,255,0.05)",
                    boxpoints="outliers")
    t.style_fig(fig, height=320, hovermode="closest", showlegend=False,
                yaxis=dict(type="log", title="Minutes (log)"))
    st.plotly_chart(fig, theme=None, config=t.PLOTLY_CONFIG)

st.write("")
with c.card("daily"):
    c.show(c.card_head("Daily purchases", ctx.period_label))
    daily = m.purchases(cur).groupby("date").size().reindex(
        __import__("pandas").date_range(*ctx.cur_range), fill_value=0)
    fig = go.Figure(go.Bar(x=daily.index, y=daily.values, marker=dict(color=t.TEAL, cornerradius=4),
                           hovertemplate="%{x|%a %d %b}: %{y:,}<extra></extra>"))
    t.style_fig(fig, height=220, xaxis=dict(tickformat="%d %b"))
    st.plotly_chart(fig, theme=None, config=t.PLOTLY_CONFIG)
