"""Funnel – big funnel, stage table and per-category funnel comparison."""
import plotly.graph_objects as go
import streamlit as st

import config
from services import metrics as m
from ui import components as c
from ui import theme as t
from ui.layout import get_ctx, require_data

ctx = get_ctx()
if not require_data(ctx):
    st.stop()

engaged = st.toggle(f"Include “Engaged” stage (viewed {config.ENGAGED_MIN_DISTINCT_PRODUCTS}+ products)",
                    value=st.session_state.get("engaged_on", config.ENGAGED_ENABLED), key="engaged_on")
stages = m.funnel(ctx.cur, engaged)
prev_stages = {s["key"]: s for s in m.funnel(ctx.prev, engaged)} if ctx.has_prev else {}

with c.card("bigfunnel"):
    c.show(c.card_head("Conversion funnel", "Unique users reaching each stage"
                       + (" (strict: must pass earlier stages)" if config.FUNNEL_STRICT else ""),
                       right=f'<span class="fl-badge">Overall <b style="color:{t.MINT}">'
                             f'{stages[-1]["pct_top"]:.2f}%</b></span>'))
    c.show(c.stepped_funnel(stages, height=300))

st.write("")
left, right = st.columns([1.35, 1], gap="medium")

with left, c.card("ftable"):
    rows = []
    for s in stages:
        p = prev_stages.get(s["key"])
        delta = c.delta_pill(m.pct_change(s["users"], p["users"] if p else None)) if ctx.has_prev else "—"
        drop = f'<span class="fl-neg">−{s["drop"]:,}</span>' if s["drop"] else "—"
        rows.append(f'<tr><td><b>{s["stage"]}</b></td><td class="r">{s["users"]:,}</td>'
                    f'<td class="r">{s["pct_prev"]:.1f}%</td><td class="r">{s["pct_top"]:.2f}%</td>'
                    f'<td class="r">{drop}</td><td class="r">{delta}</td></tr>')
    c.show(c.card_head("Stage details", ctx.period_label)
           + '<table class="fl-table" style="margin-top:12px"><thead><tr><th>Stage</th>'
             '<th class="r">Users</th><th class="r">From previous</th><th class="r">From top</th>'
             '<th class="r">Lost</th><th class="r">vs prev period</th></tr></thead><tbody>'
           + "".join(rows) + "</tbody></table>")

with right, c.card("fcat"):
    seg = m.stage_counts_by(ctx.cur, "category").head(8).sort_values("conversion")
    c.show(c.card_head("Conversion by category", "Purchasers ÷ viewers"))
    fig = go.Figure(go.Bar(
        y=[str(i) for i in seg.index], x=seg["conversion"], orientation="h",
        marker=dict(color=seg["conversion"], colorscale=t.HEAT_SCALE[1:], cornerradius=8),
        text=[f"{v:.1f}%" for v in seg["conversion"]], textposition="outside",
        textfont=dict(color="#fff"), hovertemplate="%{y}: %{x:.2f}%<extra></extra>"))
    t.style_fig(fig, height=300, hovermode="closest",
                xaxis=dict(visible=False, range=[0, seg["conversion"].max() * 1.25 if len(seg) else 1]),
                yaxis=dict(showgrid=False))
    st.plotly_chart(fig, theme=None, config=t.PLOTLY_CONFIG)

st.download_button("Download funnel CSV", data=__import__("pandas").DataFrame(stages).to_csv(index=False),
                   file_name="funnel.csv", mime="text/csv", icon=":material/download:")
