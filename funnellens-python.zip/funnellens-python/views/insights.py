"""Insights – all automated (rule-based) insights as a card grid."""
import streamlit as st

import config
from services import insights as I
from ui import components as c
from ui.layout import get_ctx, require_data

ctx = get_ctx()
if not require_data(ctx):
    st.stop()

items = I.generate(ctx.cur, ctx.prev, st.session_state.get("engaged_on", config.ENGAGED_ENABLED))

top, d1, d2 = st.columns([3, 1, 1], vertical_alignment="center")
counts = {s: sum(i.severity == s for i in items) for s in ("High", "Medium", "Opportunity")}
top.html(" ".join(f'<span class="fl-sev {s}" style="margin-right:6px">{n} {s}</span>'
                  for s, n in counts.items())
         + '<span class="fl-label" style="margin-left:8px">Rule-based, no AI model involved.</span>')
d1.download_button("CSV", I.to_frame(items).to_csv(index=False), "insights.csv", "text/csv",
                   icon=":material/download:", width="stretch", disabled=not items)
d2.download_button("Report (.md)", I.to_markdown(items, ctx.period_label), "insights.md",
                   "text/markdown", icon=":material/description:", width="stretch",
                   disabled=not items)
st.write("")

if not items:
    with c.card("noins"):
        c.empty_state("No insights yet", "Not enough activity in this selection.", "✦")
    st.stop()

for row in range(0, len(items), 3):
    cols = st.columns(3, gap="medium")
    for col, it in zip(cols, items[row:row + 3]):
        with col, c.card(f"ins-{row}-{it.rule}"):
            c.show(f'<div class="fl-card-head"><span class="fl-sev {it.severity}">{it.severity}</span>'
                   f'<span class="fl-label">{c.esc(it.rule.replace("_", " "))}</span></div>'
                   f'<div class="fl-insight-stat" style="margin-top:16px">{c.esc(it.headline)}</div>'
                   f'<div class="fl-card-title" style="margin-top:2px">{c.esc(it.label)}</div>'
                   f'<div class="fl-insight-body">{c.esc(it.body)}</div>')
    st.write("")
