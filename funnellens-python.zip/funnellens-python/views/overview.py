"""Overview – bento grid that mirrors the reference design."""
import math

import plotly.graph_objects as go
import streamlit as st

import config
from services import insights as I
from services import metrics as m
from ui import components as c
from ui import theme as t
from ui.layout import get_ctx, require_data

ctx = get_ctx()
if not require_data(ctx):
    st.stop()

cur, prev = ctx.cur, ctx.prev
engaged = st.session_state.get("engaged_on", config.ENGAGED_ENABLED)

# ---------------------------------------------------------------------------
# Row 1: funnel (2/3) + revenue (1/3)
# ---------------------------------------------------------------------------
left, right = st.columns([2, 1], gap="medium")

with left, c.card("funnel"):
    stages = m.funnel(cur, engaged)
    overall = stages[-1]["pct_top"] if stages else 0
    c.show(c.card_head("Funnel Conversion Breakdown", "Unique users per stage",
                       right=f'<span class="fl-badge">Overall conversion '
                             f'<b style="color:{t.MINT}">{overall:.2f}%</b></span>'))
    c.show(c.stepped_funnel(stages, height=220))

with right, c.card("revenue"):
    rev = m.revenue(cur)
    rev_prev = m.revenue(prev) if ctx.has_prev else None
    tops = m.top_categories(cur, 3)
    n_orders = len(m.purchases(cur))
    c.show(
        c.card_head("Total Revenue", "Sum of purchase prices")
        + f'<div style="margin-top:18px" class="fl-big">{c.countup(rev, prefix="$")}</div>'
        + f'<div style="margin-top:10px;display:flex;gap:8px;align-items:center">'
          f'{c.delta_pill(m.pct_change(rev, rev_prev), "vs prev")}'
          f'<span class="fl-label">{n_orders:,} orders</span></div>'
        + '<div class="fl-label" style="margin-top:26px">Top categories</div>'
        + c.progress_bars([(str(k), v) for k, v in tops.items()])
    )

st.write("")

# ---------------------------------------------------------------------------
# Row 2: unique visits | conversions | insights
# ---------------------------------------------------------------------------
a, b, d = st.columns(3, gap="medium")

with a, c.card("visits"):
    uu = m.unique_users(cur)
    uu_prev = m.unique_users(prev) if ctx.has_prev else None
    c.show(c.card_head("Unique Visits", "This period vs previous",
                       right=c.delta_pill(m.pct_change(uu, uu_prev)))
           + f'<div class="fl-mid" style="margin-top:12px">{c.countup(uu)}</div>')
    s_cur = m.daily_unique(cur, ctx.cur_range)
    fig = go.Figure()
    if ctx.has_prev:
        s_prev = m.daily_unique(prev, ctx.prev_range).iloc[:len(s_cur)]
        fig.add_scatter(x=s_cur.index[:len(s_prev)], y=s_prev.values, name="Previous",
                        mode="lines", line=dict(color=t.PREV_LINE, width=1.6, dash="dot", shape="spline"),
                        customdata=s_prev.index.strftime("%d %b"),
                        hovertemplate="Previous (%{customdata}): %{y:,}<extra></extra>")
    trace = dict(x=s_cur.index, y=s_cur.values, name="Current", mode="lines",
                 line=dict(color=t.CORAL, width=2.6, shape="spline"),
                 hovertemplate="Current: %{y:,}<extra></extra>", fill="tozeroy")
    try:
        fig.add_scatter(**trace, fillgradient=dict(type="vertical", colorscale=[
            [0, "rgba(251,113,133,0)"], [1, "rgba(251,113,133,0.28)"]]))
    except (ValueError, TypeError):
        fig.add_scatter(**trace, fillcolor="rgba(251,113,133,0.10)")
    t.style_fig(fig, height=170, showlegend=True,
                legend=dict(orientation="h", y=1.15, x=0),
                xaxis=dict(tickformat="%d %b", nticks=5),
                yaxis=dict(tickformat="~s", nticks=4))
    st.plotly_chart(fig, theme=None, config=t.PLOTLY_CONFIG)

with b, c.card("conversions"):
    wd = m.purchases_by_weekday(cur)
    total = int(wd.sum())
    total_prev = len(m.purchases(prev)) if ctx.has_prev else None
    peak = wd.idxmax() if total else "—"
    c.show(c.card_head("Total Conversions", "Purchases by weekday",
                       right=f'<span class="fl-badge">🔥 Peak: {peak}</span>')
           + f'<div class="fl-mid" style="margin-top:12px">{c.countup(total)}</div>')
    # dotted "bars": each column is a stack of dots
    mx = max(wd.max(), 1)
    xs, ys, colors, vals = [], [], [], []
    for day, v in wd.items():
        k = max(1, math.ceil(v / mx * 9)) if v else 0
        for j in range(k):
            xs.append(day)
            ys.append(j + 1)
            colors.append("#FFFFFF" if day == peak else "rgba(224,242,254,0.45)")
            vals.append(int(v))
    fig = go.Figure(go.Scatter(x=xs, y=ys, mode="markers", customdata=vals,
                               marker=dict(size=9, color=colors, line=dict(width=0)),
                               hovertemplate="%{x}: %{customdata:,} purchases<extra></extra>"))
    t.style_fig(fig, height=150, hovermode="closest", showlegend=False,
                xaxis=dict(categoryorder="array", categoryarray=list(wd.index)),
                yaxis=dict(visible=False, range=[0, 10.5]))
    st.plotly_chart(fig, theme=None, config=t.PLOTLY_CONFIG)
    prev_txt = f"{total_prev:,} last period" if total_prev is not None else "No prior period"
    c.show(f'<div class="fl-deltabox"><span class="fl-label">{prev_txt}</span>'
           f'{c.delta_pill(m.pct_change(total, total_prev))}</div>')

with d, c.card("insights"):
    items = I.generate(cur, prev, engaged)
    head, btn = st.columns([5, 1], vertical_alignment="center")
    with head:
        c.show('<div style="display:flex;gap:10px;align-items:center"><div class="fl-spark">✦</div>'
               '<div><div class="fl-card-title">Automated Insights</div>'
               '<div class="fl-card-sub">Rule-based · generated from your data</div></div></div>')
    with btn:
        if st.button("→", key="next_insight", help="Next insight", disabled=len(items) < 2):
            st.session_state["insight_idx"] = st.session_state.get("insight_idx", 0) + 1
    if items:
        i = st.session_state.get("insight_idx", 0) % len(items)
        it = items[i]
        c.show(f'<div style="margin-top:14px"><span class="fl-sev {it.severity}">{it.severity}</span></div>'
               f'<div style="margin-top:12px" class="fl-insight-stat">{c.esc(it.headline)}</div>'
               f'<div class="fl-card-title" style="margin-top:2px">{c.esc(it.label)}</div>'
               f'<div class="fl-insight-body">{c.esc(it.body)}</div>'
               f'<div class="fl-label" style="margin-top:14px">{i + 1} / {len(items)}</div>')
    else:
        c.show('<div class="fl-insight-body">Not enough data for insights in this selection.</div>')
