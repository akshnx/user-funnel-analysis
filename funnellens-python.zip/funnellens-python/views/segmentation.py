"""Segmentation – grouped bars by category/brand and an hour × weekday heatmap."""
import plotly.graph_objects as go
import streamlit as st

from services import metrics as m
from ui import components as c
from ui import theme as t
from ui.layout import get_ctx, require_data

ctx = get_ctx()
if not require_data(ctx):
    st.stop()

cur = ctx.cur

with c.card("groups"):
    head, ctl = st.columns([2, 1], vertical_alignment="center")
    with head:
        c.show(c.card_head("Funnel stages by segment", "Unique users who viewed, carted and purchased"))
    with ctl:
        by = st.segmented_control("Group by", ["category", "brand"], default="category",
                                  key="seg_by", label_visibility="collapsed") or "category"
    seg = m.stage_counts_by(cur, by)
    seg = seg[seg.index.astype(str) != "unknown"].head(10)
    fig = go.Figure()
    for col, name, color in [("view", "Viewed", t.ICE), ("cart", "Carted", t.TEAL),
                             ("purchase", "Purchased", t.CORAL)]:
        fig.add_bar(x=[str(i) for i in seg.index], y=seg[col], name=name,
                    marker=dict(color=color, cornerradius=6),
                    hovertemplate=f"{name}: %{{y:,}}<extra></extra>")
    t.style_fig(fig, height=340, barmode="group", bargroupgap=0.08,
                yaxis=dict(type="log", title="Users (log scale)", tickformat="~s"))
    st.plotly_chart(fig, theme=None, config=t.PLOTLY_CONFIG)

st.write("")
left, right = st.columns([1.6, 1], gap="medium")

with left, c.card("heat"):
    head, ctl = st.columns([2, 1], vertical_alignment="center")
    with head:
        c.show(c.card_head("Activity by hour and weekday", "When your visitors are active"))
    with ctl:
        ev = st.selectbox("Event", ["all", "view", "cart", "purchase"], key="heat_ev",
                          label_visibility="collapsed",
                          format_func=lambda x: "All events" if x == "all" else x.title() + "s")
    hm = m.heatmap(cur, ev)
    fig = go.Figure(go.Heatmap(z=hm.values, x=[f"{h:02d}" for h in hm.columns], y=list(hm.index),
                               colorscale=t.HEAT_SCALE, xgap=3, ygap=3, showscale=False,
                               hovertemplate="%{y} %{x}:00 · %{z:,}<extra></extra>"))
    t.style_fig(fig, height=300, hovermode="closest", yaxis=dict(autorange="reversed", showgrid=False),
                xaxis=dict(title="Hour of day"))
    st.plotly_chart(fig, theme=None, config=t.PLOTLY_CONFIG)

with right, c.card("segrev"):
    seg = m.stage_counts_by(cur, "category").sort_values("revenue", ascending=False).head(6)
    c.show(c.card_head("Revenue by category", "Top 6")
           + c.progress_bars([(str(k), v) for k, v in seg["revenue"].items()])
           + '<div class="fl-label" style="margin-top:20px">Best converting: '
           + (f'<b style="color:#fff;text-transform:capitalize">{seg["conversion"].idxmax()}</b> '
              f'({seg["conversion"].max():.1f}%)' if len(seg) else "—") + "</div>")
