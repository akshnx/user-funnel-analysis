"""Data – upload, sample data and the cleaning summary."""
import pandas as pd
import streamlit as st

import config
from ui import components as c
from ui.layout import data_source_controls

left, right = st.columns([1, 2], gap="medium")

with left, c.card("upload"):
    c.show(c.card_head("Data source", "REES46 ‘eCommerce behavior data’ format"))
    data_source_controls("datapage")
    c.show('<div class="fl-label" style="margin-top:8px;line-height:1.6">Required: '
           + ", ".join(f"<code>{x}</code>" for x in config.REQUIRED_COLUMNS)
           + "<br>Optional: " + ", ".join(f"<code>{x}</code>" for x in config.OPTIONAL_COLUMNS)
           + (f"<br>Large files are capped at the first {config.MAX_UPLOAD_ROWS:,} rows."
              if config.MAX_UPLOAD_ROWS else "") + "</div>")

with right, c.card("summary"):
    s = st.session_state.get("summary")
    if not s:
        c.empty_state("No data loaded", "Upload a CSV or use sample data to begin.")
    else:
        ev = s["event_counts"]
        c.show(c.card_head("Cleaning summary", st.session_state.get("source", ""))
               + '<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:18px;margin-top:16px">'
               + "".join(f'<div><div class="fl-label">{k}</div><div class="fl-mid">{v}</div></div>'
                         for k, v in [("Rows in", f"{s['rows_in']:,}"), ("Rows kept", f"{s['rows_out']:,}"),
                                      ("Users", f"{s['users']:,}"), ("Products", f"{s['products']:,}")])
               + "</div>")
        fixes = [
            ("Duplicate rows removed", s["duplicates"]),
            ("Rows missing time / user / product", s["missing_required"]),
            ("Unknown event types dropped", s["invalid_event_types"]),
            ("Negative prices dropped", s["negative_prices"]),
            ("Missing prices set to 0", s["missing_price"]),
            ("Missing category → “unknown”", s["missing_category"]),
            ("Missing brand → “unknown”", s["missing_brand"]),
        ]
        rows = "".join(f'<tr><td>{k}</td><td class="r">{v:,}</td></tr>' for k, v in fixes)
        evs = " · ".join(f"{k}: <b style='color:#fff'>{ev.get(k, 0):,}</b>" for k in config.VALID_EVENT_TYPES)
        c.show(f'<table class="fl-table" style="margin-top:14px"><tbody>{rows}</tbody></table>'
               f'<div class="fl-label" style="margin-top:12px">{evs}</div>'
               f'<div class="fl-label" style="margin-top:6px">Range: {s["date_min"]:%d %b %Y} – '
               f'{s["date_max"]:%d %b %Y}</div>')

df = st.session_state.get("df")
if df is not None:
    st.write("")
    with c.card("preview"):
        c.show(c.card_head("Preview", "First 200 cleaned rows"))
        cols = ["event_time", "event_type", "product_id", "category_code", "brand", "price",
                "user_id", "user_session"]
        st.dataframe(df[cols].head(200), width="stretch", hide_index=True, height=360)
        st.download_button("Download cleaned sample (10k rows)",
                           df[cols].head(10_000).to_csv(index=False), "cleaned_sample.csv", "text/csv",
                           icon=":material/download:")
_ = pd
