"""Page header, filter bar and data-source handling (shared by all pages)."""
from __future__ import annotations

import streamlit as st

import config
from services import data as D
from ui import components as c


# ---------------------------------------------------------------------------
# Data source state
# ---------------------------------------------------------------------------
@st.cache_data(show_spinner=False)
def _sample() -> tuple:
    return D.clean(D.make_sample_data())


@st.cache_data(show_spinner=False, max_entries=2)
def _from_upload(raw_bytes: bytes, name: str) -> tuple:
    import io
    return D.clean(D.read_csv(io.BytesIO(raw_bytes)))


def load_sample() -> None:
    with st.spinner("Generating sample data…"):
        df, summary = _sample()
    st.session_state.update(df=df, summary=summary, source="Sample data (synthetic REES46)")


def load_upload(file) -> bool:
    try:
        with st.spinner(f"Reading and cleaning {file.name}…"):
            df, summary = _from_upload(file.getvalue(), file.name)
    except D.DataError as exc:
        st.error(f"**Couldn't use this file.** {exc}")
        return False
    except Exception as exc:  # noqa: BLE001
        st.error(f"**Something went wrong reading the file.** ({exc.__class__.__name__}) "
                 "Please check it is a REES46-style CSV.")
        return False
    st.session_state.update(df=df, summary=summary, source=file.name, upload_id=file.file_id)
    return True


def data_source_controls(location: str = "popover") -> None:
    """CSV uploader + 'Use sample data' button."""
    up = st.file_uploader("Upload REES46 CSV", type=["csv"], key=f"uploader_{location}",
                          help="Columns: event_time, event_type, product_id, category_id, "
                               "category_code, brand, price, user_id, user_session")
    if up is not None and st.session_state.get("upload_id") != up.file_id:
        if load_upload(up):
            st.rerun()
    if st.button("Use sample data", key=f"sample_{location}", width="stretch",
                 type="primary" if "df" not in st.session_state else "secondary"):
        load_sample()
        st.rerun()
    if "source" in st.session_state:
        st.caption(f"Loaded: **{st.session_state['source']}**")


# ---------------------------------------------------------------------------
# Header + filters
# ---------------------------------------------------------------------------
def render_header(title: str, show_filters: bool = True) -> D.FilterContext:
    df = st.session_state.get("df")
    ctx = D.FilterContext(df_all=df)

    left, right = st.columns([1.15, 2], vertical_alignment="bottom")
    with left:
        sub = config.PAGE_SUBTITLES.get(title, "")
        c.show(f'<div class="fl-title">{c.esc(title)}</div><div class="fl-subtitle">{c.esc(sub)}</div>')

    with right:
        if show_filters and df is not None:
            cats = [config.ALL_CATEGORIES] + sorted(str(x) for x in df["category"].cat.categories)
            dmin, dmax = df["date"].min().date(), df["date"].max().date()
            custom = st.session_state.get("f_preset") == "Custom"
            widths = [1.2, 1.1, 1.3, 0.8] if custom else [1.2, 1.1, 0.8]
            cols = st.columns(widths, vertical_alignment="bottom")
            ctx.category = cols[0].selectbox("Category", cats, key="f_category")
            ctx.preset = cols[1].selectbox("Date range", config.DATE_PRESETS, key="f_preset",
                                           index=config.DATE_PRESETS.index(config.DEFAULT_PRESET))
            custom_rng = None
            if custom:
                custom_rng = cols[2].date_input("From – to", value=(max(dmin, dmax.replace(day=1)), dmax),
                                                min_value=dmin, max_value=dmax, key="f_custom")
            with cols[-1].popover("Data", icon=":material/upload:", width="stretch"):
                data_source_controls("header")
            ctx.cur_range, ctx.prev_range = D.resolve_period(dmin, dmax, ctx.preset, custom_rng)
            ctx.cur = D.slice_df(df, ctx.cur_range, ctx.category)
            ctx.prev = D.slice_df(df, ctx.prev_range, ctx.category)
        elif show_filters:
            _, r = st.columns([2, 1])
            with r.popover("Load data", icon=":material/upload:", width="stretch"):
                data_source_controls("header")

    if ctx.cur_range:
        prev = (f" · compared with {ctx.prev_range[0]:%d %b} – {ctx.prev_range[1]:%d %b}"
                if ctx.prev_range else " · no earlier data to compare")
        c.show(f'<div class="fl-period">{ctx.period_label}{prev}</div>')
    st.write("")
    return ctx


def get_ctx() -> D.FilterContext:
    return st.session_state.get("_ctx") or D.FilterContext()


def require_data(ctx: D.FilterContext) -> bool:
    """Show the empty state + call to action when nothing is loaded."""
    if ctx.has_data:
        if ctx.cur is not None and ctx.cur.empty:
            with c.card("empty"):
                c.empty_state("Nothing in this selection",
                              "Try a wider date range or another category.", "⌕")
            return False
        return True
    with c.card("empty"):
        c.empty_state("Let's look at your funnel",
                      "Upload a CSV or use sample data to begin.")
        _, mid, _ = st.columns([1, 1, 1])
        with mid:
            data_source_controls("empty")
    return False
