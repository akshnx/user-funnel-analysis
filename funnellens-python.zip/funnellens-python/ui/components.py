"""Reusable HTML building blocks (cards, pills, funnel, empty states)."""
from __future__ import annotations

import html
import math
import time

import streamlit as st

from ui import theme as t


# ---------------------------------------------------------------------------
# Formatting
# ---------------------------------------------------------------------------
def fmt_int(n: float) -> str:
    return f"{int(round(n)):,}"


def fmt_money(x: float, short: bool = False) -> str:
    if short:
        for div, suf in ((1e9, "B"), (1e6, "M"), (1e3, "k")):
            if abs(x) >= div:
                return f"${x / div:,.1f}{suf}"
    return f"${x:,.0f}"


def fmt_k(n: float) -> str:
    if abs(n) >= 1e6:
        return f"{n / 1e6:.1f}M".replace(".0M", "M")
    if abs(n) >= 1e3:
        return f"{n / 1e3:.1f}k".replace(".0k", "k")
    return f"{n:.0f}"


def esc(s) -> str:
    return html.escape(str(s))


# ---------------------------------------------------------------------------
# Primitives
# ---------------------------------------------------------------------------
def card(key: str):
    """A styled card container. Use as `with card("revenue"): ...`."""
    return st.container(key=f"card-{key}")


def show(markup: str) -> None:
    """Render raw HTML (no markdown processing, so indentation is safe)."""
    st.html(markup)


def countup(value: float, decimals: int = 0, prefix: str = "", suffix: str = "") -> str:
    """Number that animates from 0 on load (see `count_up_script`)."""
    shown = f"{prefix}{value:,.{decimals}f}{suffix}"
    return (f'<span class="countup" data-to="{value}" data-dec="{decimals}" '
            f'data-pre="{esc(prefix)}" data-suf="{esc(suffix)}">{shown}</span>')


def delta_pill(pct: float | None, label: str = "") -> str:
    if pct is None:
        return '<span class="fl-pill flat">no prior period</span>'
    cls = "up" if pct > 0.05 else "down" if pct < -0.05 else "flat"
    arrow = "↗" if cls == "up" else "↘" if cls == "down" else "→"
    lab = f' <span style="opacity:.7;font-weight:500">{esc(label)}</span>' if label else ""
    return f'<span class="fl-pill {cls}">{arrow} {pct:+.1f}%{lab}</span>'


def card_head(title: str, sub: str = "", right: str = "") -> str:
    s = f'<div class="fl-card-sub">{esc(sub)}</div>' if sub else ""
    return (f'<div class="fl-card-head"><div><div class="fl-card-title">{esc(title)}</div>{s}</div>'
            f'<div>{right}</div></div>')


def progress_bars(items: list[tuple[str, float]], fmt=fmt_money) -> str:
    if not items:
        return '<div class="fl-muted" style="font-size:13px;margin-top:12px">No purchases in this period.</div>'
    top = max(v for _, v in items) or 1
    rows = []
    for i, (name, v) in enumerate(items):
        rows.append(
            f'<div class="fl-prog"><div class="fl-prog-row"><span class="nm">{esc(name)}</span>'
            f'<span class="vl">{fmt(v)}</span></div><div class="fl-track">'
            f'<div class="fl-fill" style="width:{max(v / top * 100, 2):.1f}%;animation-delay:{i * .12:.2f}s">'
            f'</div></div></div>')
    return "".join(rows)


def empty_state(title: str = "No data yet",
                text: str = "Upload a CSV or use sample data to begin.", icon: str = "◆") -> None:
    show(f'<div class="fl-empty"><div class="ic">{icon}</div><h3>{esc(title)}</h3>'
         f'<p>{esc(text)}</p></div>')


def user_chip(name: str) -> None:
    show(f'<div class="fl-userchip"><div class="av">{esc(name[:1].upper())}</div>'
         f'<span class="nm">{esc(name)}</span><span class="dot"></span></div>')


# ---------------------------------------------------------------------------
# Stepped funnel (custom SVG)
# ---------------------------------------------------------------------------
def _nice_max(v: float) -> tuple[float, float]:
    if v <= 0:
        return 1, 0.25
    raw = v / 4
    mag = 10 ** math.floor(math.log10(raw))
    step = next(s * mag for s in (1, 2, 2.5, 5, 10) if s * mag >= raw)
    return step * 4, step


def stepped_funnel(stages: list[dict], height: int = 230) -> str:
    """Connected, glowing, gradient step funnel. `stages` from metrics.funnel()."""
    if not stages:
        return '<div class="fl-muted">No funnel data.</div>'
    n = len(stages)
    W, H = 1000.0, float(height)
    top_pad = 6.0
    ymax, ystep = _nice_max(max(s["users"] for s in stages))
    cw = W / n
    tw = cw * 0.09  # half-width of the connecting curve
    ys = [H - (s["users"] / ymax) * (H - top_pad) for s in stages]
    ys = [min(y, H - 3) for y in ys]

    # outline path (top edge) & closed area
    d_top = f"M0,{ys[0]:.1f} "
    for i in range(n):
        x0 = i * cw
        x_end = (i + 1) * cw
        if i < n - 1:
            d_top += f"L{x_end - tw:.1f},{ys[i]:.1f} "
            d_top += (f"C{x_end:.1f},{ys[i]:.1f} {x_end:.1f},{ys[i + 1]:.1f} "
                      f"{x_end + tw:.1f},{ys[i + 1]:.1f} ")
        else:
            d_top += f"L{W:.1f},{ys[i]:.1f} "
        _ = x0
    d_area = d_top + f"L{W:.1f},{H:.1f} L0,{H:.1f} Z"

    grid = "".join(
        f'<line x1="0" x2="{W}" y1="{H - (k * ystep / ymax) * (H - top_pad):.1f}" '
        f'y2="{H - (k * ystep / ymax) * (H - top_pad):.1f}" stroke="rgba(255,255,255,0.05)" '
        f'stroke-dasharray="3 5" vector-effect="non-scaling-stroke"/>' for k in range(1, 5))

    # glowing vertical seams between steps
    seams = "".join(
        f'<line x1="{i * cw:.1f}" x2="{i * cw:.1f}" y1="{ys[i]:.1f}" y2="{H}" '
        f'stroke="url(#seam)" stroke-width="2" vector-effect="non-scaling-stroke" filter="url(#glow)"/>'
        for i in range(1, n))

    svg = f"""<svg viewBox="0 0 {W:.0f} {H:.0f}" preserveAspectRatio="none" style="height:{height}px">
<defs>
<linearGradient id="fg" x1="0" x2="1" y1="0" y2="0">
<stop offset="0%" stop-color="{t.GREEN}"/><stop offset="55%" stop-color="{t.TEAL}"/>
<stop offset="100%" stop-color="{t.MINT}"/></linearGradient>
<linearGradient id="fade" x1="0" x2="0" y1="0" y2="1">
<stop offset="0%" stop-color="#fff" stop-opacity="0.95"/>
<stop offset="55%" stop-color="#fff" stop-opacity="0.35"/>
<stop offset="100%" stop-color="#fff" stop-opacity="0.04"/></linearGradient>
<mask id="fmask"><rect x="0" y="0" width="{W}" height="{H}" fill="url(#fade)"/></mask>
<linearGradient id="seam" x1="0" x2="0" y1="0" y2="1">
<stop offset="0%" stop-color="#ECFDF5" stop-opacity="0.95"/>
<stop offset="100%" stop-color="{t.MINT}" stop-opacity="0"/></linearGradient>
<filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
<feGaussianBlur stdDeviation="4" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
</filter>
</defs>
{grid}
<g class="shape">
<path d="{d_area}" fill="url(#fg)" mask="url(#fmask)" opacity="0.9"/>
<path d="{d_top}" fill="none" stroke="url(#fg)" stroke-width="7" opacity="0.35"
 vector-effect="non-scaling-stroke" filter="url(#glow)"/>
<path d="{d_top}" fill="none" stroke="#D1FAE5" stroke-width="2" vector-effect="non-scaling-stroke"/>
{seams}
</g>
</svg>"""
    svg = "".join(line.strip() + " " for line in svg.splitlines())

    cols = f"grid-template-columns:repeat({n}, 1fr)"
    heads, caps = [], []
    for i, s in enumerate(stages):
        drop = ""
        if i > 0:
            drop = f'<span class="fl-neg">{s["pct_prev"] - 100:+.1f}%</span>'
        heads.append(f'<div class="fl-fstage"><div class="nm">{esc(s["stage"])} {drop}</div>'
                     f'<div class="val">{countup(s["users"])}</div></div>')
        if i == 0:
            cap = "<b>100%</b> of visitors"
        else:
            prev = stages[i - 1]["stage"].lower()
            verb = {"engaged": "engaged", "cart": "added to cart", "purchase": "purchased"}.get(s["key"], "")
            cap = f'<b>{s["pct_prev"]:.0f}%</b> of {esc(prev)} {verb}'
        caps.append(f'<div class="fl-fcap">{cap}</div>')

    ticks = "".join(f"<span>{fmt_k(ymax - k * ystep)}</span>" for k in range(5))
    pad = "padding-left:44px"
    return (f'<div class="fl-funnel">'
            f'<div class="fl-funnel-grid" style="{cols};{pad}">{"".join(heads)}</div>'
            f'<div class="fl-funnel-plot" style="{pad}"><div class="fl-yaxis" '
            f'style="height:{height}px">{ticks}</div>{svg}</div>'
            f'<div class="fl-funnel-grid" style="{cols};{pad}">{"".join(caps)}</div></div>')


# ---------------------------------------------------------------------------
# Count-up animation (tiny same-origin script that animates .countup spans)
# ---------------------------------------------------------------------------
_COUNTUP_JS = """
<script>
(function(){
  const doc = window.parent.document;
  function fmt(v, dec){ return v.toLocaleString('en-US',{minimumFractionDigits:dec, maximumFractionDigits:dec}); }
  function run(el){
    const to = parseFloat(el.dataset.to), dec = parseInt(el.dataset.dec||'0');
    if (isNaN(to) || el.dataset.done === String(to)) return;
    el.dataset.done = String(to);
    const pre = el.dataset.pre||'', suf = el.dataset.suf||'', t0 = performance.now(), dur = 1100;
    function step(now){
      const p = Math.min(1, (now - t0)/dur), e = 1 - Math.pow(1 - p, 3);
      el.textContent = pre + fmt(to*e, dec) + suf;
      if (p < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }
  function scan(){ doc.querySelectorAll('.countup').forEach(run); }
  scan();
  const obs = new MutationObserver(scan);
  obs.observe(doc.body, {childList:true, subtree:true});
  setTimeout(()=>obs.disconnect(), 4000);
})();
</script>
"""


def count_up_script() -> None:
    """Inject the count-up script. Numbers are already correct if JS is unavailable."""
    js = _COUNTUP_JS.replace("window.parent.document", "document")
    with st.container(key="fl-countup-js"):
        try:
            st.html(js + f"<!-- {time.time()} -->", unsafe_allow_javascript=True)
        except TypeError:  # older Streamlit: fall back to a same-origin iframe
            import streamlit.components.v1 as components
            components.html(_COUNTUP_JS + f"<!-- {time.time()} -->", height=0)
