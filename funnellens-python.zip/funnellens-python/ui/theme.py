"""Design tokens, global CSS and the shared Plotly template.

Import `inject_css()` once per run (app.py does this) and every Plotly figure
picks up the "funnellens" template automatically.
"""
from __future__ import annotations

import plotly.graph_objects as go
import plotly.io as pio
import streamlit as st

# ---------------------------------------------------------------------------
# Tokens
# ---------------------------------------------------------------------------
BG = "#050506"
CARD = "#0E0F12"
CARD_HOVER = "#121318"
BORDER = "rgba(255,255,255,0.08)"
TEXT = "#FFFFFF"
MUTED = "#9CA3AF"
DIM = "#6B7280"

GREEN = "#22C55E"
TEAL = "#14B8A6"
MINT = "#34D399"
PINK = "#EC4899"
PURPLE = "#A855F7"
CORAL = "#FB7185"
ICE = "#E0F2FE"
RED = "#EF4444"
PREV_LINE = "rgba(255,255,255,0.28)"

FUNNEL_GRADIENT = [GREEN, TEAL, MINT]
FONT = "Inter, 'Plus Jakarta Sans', system-ui, -apple-system, Segoe UI, sans-serif"

# green/teal sequential scale for heatmaps
HEAT_SCALE = [[0.0, "#0B0D10"], [0.15, "#0B2A22"], [0.4, "#0F5F4B"],
              [0.7, TEAL], [1.0, MINT]]
SERIES = [CORAL, TEAL, PURPLE, ICE, GREEN, PINK]

# ---------------------------------------------------------------------------
# Plotly template
# ---------------------------------------------------------------------------
_axis = dict(showgrid=False, zeroline=False, showline=False, ticks="",
             tickfont=dict(color=DIM, size=11), title=dict(font=dict(color=MUTED, size=12)),
             linecolor=BORDER)

pio.templates["funnellens"] = go.layout.Template(layout=go.Layout(
    font=dict(family=FONT, color=MUTED, size=12),
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(0,0,0,0)",
    colorway=SERIES,
    margin=dict(l=8, r=8, t=8, b=8),
    xaxis=_axis,
    yaxis={**_axis, "showgrid": True, "gridcolor": "rgba(255,255,255,0.04)", "gridwidth": 1},
    legend=dict(orientation="h", y=1.08, x=0, font=dict(color=MUTED, size=11),
                bgcolor="rgba(0,0,0,0)"),
    hoverlabel=dict(bgcolor="#16181D", bordercolor="rgba(255,255,255,0.12)",
                    font=dict(family=FONT, color=TEXT, size=12), align="left"),
    hovermode="x unified",
    bargap=0.35,
    coloraxis=dict(colorscale=HEAT_SCALE),
))
pio.templates.default = "funnellens"

PLOTLY_CONFIG = {"displayModeBar": False, "responsive": True}


def style_fig(fig: go.Figure, height: int = 220, **layout) -> go.Figure:
    fig.update_layout(template="funnellens", height=height, **layout)
    return fig


# ---------------------------------------------------------------------------
# CSS
# ---------------------------------------------------------------------------
CSS = f"""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');

:root {{
  --bg:{BG}; --card:{CARD}; --border:{BORDER}; --text:{TEXT}; --muted:{MUTED}; --dim:{DIM};
  --green:{GREEN}; --teal:{TEAL}; --mint:{MINT}; --pink:{PINK}; --purple:{PURPLE};
  --coral:{CORAL}; --ice:{ICE}; --red:{RED};
  --radius:24px;
}}

html, body, [class*="st-"], .stApp, button, input, textarea, select {{
  font-family:{FONT} !important;
}}
/* keep Material icons rendering */
[data-testid="stIconMaterial"], .material-symbols-rounded, span[class*="material"] {{
  font-family:'Material Symbols Rounded' !important;
}}

/* ---------- page ---------- */
.stApp {{
  background:
    radial-gradient(1200px 420px at 50% -120px, rgba(34,197,94,0.10), transparent 70%),
    radial-gradient(800px 300px at 85% -80px, rgba(168,85,247,0.07), transparent 70%),
    {BG};
  background-attachment: fixed;
}}
.block-container {{ padding-top:5.2rem !important; padding-bottom:3rem; max-width:1440px; }}

/* ---------- hide streamlit chrome ---------- */
#MainMenu, footer, [data-testid="stToolbar"], [data-testid="stDecoration"],
[data-testid="stStatusWidget"], [data-testid="stAppDeployButton"],
[data-testid="stMainMenu"], [data-testid="stSidebarCollapsedControl"],
[data-testid="stSidebar"], [data-testid="collapsedControl"] {{ display:none !important; }}

/* ---------- top nav bar (st.navigation position="top") ---------- */
header[data-testid="stHeader"] {{
  background:rgba(5,5,6,0.72) !important;
  backdrop-filter:blur(14px); -webkit-backdrop-filter:blur(14px);
  border-bottom:1px solid {BORDER};
  height:64px;
}}
header[data-testid="stHeader"] > div {{ height:64px; align-items:center; }}
[data-testid="stLogo"], [data-testid="stHeaderLogo"] img, header img {{ height:30px !important; max-height:30px !important; }}

/* nav container -> pill track */
[data-testid="stTopNav"] {{
  background:rgba(255,255,255,0.04);
  border:1px solid {BORDER};
  border-radius:999px;
  padding:4px !important;
  gap:2px;
  flex:0 0 auto !important;
  margin:0 auto;
}}
[data-testid="stTopNavLinkContainer"] {{ margin:0 !important; padding:0 !important; }}
[data-testid="stTopNavLink"] {{
  border-radius:999px !important;
  padding:6px 16px !important;
  color:rgba(255,255,255,0.62) !important;
  background:transparent !important;
  transition:background .2s ease, color .2s ease;
  text-decoration:none !important;
  border:none !important;
}}
[data-testid="stTopNavLink"] * {{
  color:inherit !important; font-weight:500 !important; font-size:14px !important;
}}
[data-testid="stTopNavLink"]:hover {{
  color:#fff !important; background:rgba(255,255,255,0.06) !important;
}}
[data-testid="stTopNavLink"][aria-current="page"], [data-testid="stTopNavLink"].active,
[data-testid="stTopNavLink"][aria-selected="true"], [data-testid="stTopNavLink"][data-active="true"] {{
  background:#fff !important; color:#0B0B0D !important;
  box-shadow:0 4px 20px rgba(255,255,255,0.15);
}}
[data-testid="stTopNavLink"][aria-current="page"] *, [data-testid="stTopNavLink"].active *,
[data-testid="stTopNavLink"][aria-selected="true"] *, [data-testid="stTopNavLink"][data-active="true"] * {{
  color:#0B0B0D !important; font-weight:600 !important;
}}
/* the active-tab underline Streamlit draws */
[data-testid="stTopNavLink"]::after, [data-testid="stTopNavLink"]::before {{ display:none !important; }}
div[class*="st-key-fl-countup-js"] {{ display:none !important; }}

/* user chip (fixed, top-right) */
.fl-userchip {{
  position:fixed; top:14px; right:28px; z-index:1000100;
  display:flex; align-items:center; gap:10px;
  padding:4px 14px 4px 4px; border-radius:999px;
  background:rgba(255,255,255,0.04); border:1px solid {BORDER};
  color:#fff; font-size:13px; font-weight:500;
}}
.fl-userchip .av {{
  width:28px; height:28px; border-radius:50%;
  background:linear-gradient(135deg,{PINK},{PURPLE});
  display:grid; place-items:center; font-weight:700; font-size:12px;
}}
.fl-userchip .dot {{ width:7px; height:7px; border-radius:50%; background:{GREEN};
  box-shadow:0 0 8px {GREEN}; }}
@media (max-width: 900px) {{ .fl-userchip span.nm {{ display:none; }} }}

/* ---------- page header ---------- */
.fl-title {{ font-size:40px; font-weight:700; letter-spacing:-0.03em; color:#fff;
  line-height:1.1; margin:0; }}
.fl-subtitle {{ color:{MUTED}; font-size:14px; margin-top:6px; }}
.fl-period {{ color:{DIM}; font-size:12px; margin-top:2px; }}

/* ---------- cards (st.container(key="card-...")) ---------- */
div[class*="st-key-card"] {{
  background:linear-gradient(180deg, rgba(255,255,255,0.025), rgba(255,255,255,0) 40%), {CARD};
  border:1px solid {BORDER};
  border-radius:var(--radius);
  padding:22px 24px 18px 24px;
  box-shadow: inset 0 1px 0 rgba(255,255,255,0.05), inset 0 0 40px rgba(255,255,255,0.015),
              0 10px 30px rgba(0,0,0,0.35);
  transition:transform .25s ease, box-shadow .25s ease, border-color .25s ease;
  height:100%;
  gap:0.6rem;
}}
div[class*="st-key-card"]:hover {{
  transform:translateY(-3px);
  border-color:rgba(255,255,255,0.14);
  box-shadow: inset 0 1px 0 rgba(255,255,255,0.07), inset 0 0 40px rgba(255,255,255,0.02),
              0 18px 40px rgba(0,0,0,0.5);
}}
/* equal-height cards in a row */
[data-testid="stHorizontalBlock"]:has(div[class*="st-key-card"]) {{ align-items:stretch; }}
[data-testid="stHorizontalBlock"]:has(div[class*="st-key-card"]) > [data-testid="stColumn"] > div {{ height:100%; }}

.fl-card-head {{ display:flex; justify-content:space-between; align-items:flex-start; gap:12px; }}
.fl-card-title {{ color:#fff; font-size:15px; font-weight:600; letter-spacing:-0.01em; }}
.fl-card-sub {{ color:{MUTED}; font-size:12px; margin-top:2px; }}
.fl-label {{ color:{MUTED}; font-size:12px; font-weight:500; }}
.fl-big {{ color:#fff; font-size:44px; font-weight:700; letter-spacing:-0.035em; line-height:1.05; }}
.fl-mid {{ color:#fff; font-size:28px; font-weight:700; letter-spacing:-0.03em; line-height:1.1; }}
.fl-muted {{ color:{MUTED}; }}
.fl-neg {{ color:{RED}; font-size:12px; font-weight:600; }}
.fl-pos {{ color:{GREEN}; font-size:12px; font-weight:600; }}

/* pills & badges */
.fl-pill {{ display:inline-flex; align-items:center; gap:4px; padding:3px 10px; border-radius:999px;
  font-size:12px; font-weight:600; white-space:nowrap; }}
.fl-pill.up {{ color:{GREEN}; border:1px solid rgba(34,197,94,0.55); background:rgba(34,197,94,0.08); }}
.fl-pill.down {{ color:{RED}; border:1px solid rgba(239,68,68,0.5); background:rgba(239,68,68,0.08); }}
.fl-pill.flat {{ color:{MUTED}; border:1px solid {BORDER}; background:rgba(255,255,255,0.03); }}
.fl-badge {{ display:inline-flex; align-items:center; gap:6px; padding:4px 10px; border-radius:10px;
  font-size:12px; font-weight:500; color:#fff; background:rgba(255,255,255,0.06); border:1px solid {BORDER}; }}
.fl-sev {{ display:inline-block; padding:3px 10px; border-radius:999px; font-size:11px; font-weight:700;
  letter-spacing:.04em; text-transform:uppercase; }}
.fl-sev.High {{ color:{RED}; background:rgba(239,68,68,0.1); border:1px solid rgba(239,68,68,0.4); }}
.fl-sev.Medium {{ color:#FBBF24; background:rgba(251,191,36,0.08); border:1px solid rgba(251,191,36,0.35); }}
.fl-sev.Opportunity {{ color:{MINT}; background:rgba(52,211,153,0.08); border:1px solid rgba(52,211,153,0.35); }}

/* delta box (conversions card) */
.fl-deltabox {{ display:flex; justify-content:space-between; align-items:center; padding:10px 14px;
  border-radius:14px; background:rgba(255,255,255,0.03); border:1px solid {BORDER}; }}

/* progress bars */
.fl-prog {{ margin-top:14px; }}
.fl-prog-row {{ display:flex; justify-content:space-between; font-size:13px; margin-bottom:7px; }}
.fl-prog-row .nm {{ color:{MUTED}; text-transform:capitalize; }}
.fl-prog-row .vl {{ color:#fff; font-weight:600; }}
.fl-track {{ height:10px; border-radius:999px; background:rgba(255,255,255,0.05); overflow:hidden; }}
.fl-fill {{ height:100%; border-radius:999px; background:linear-gradient(90deg,{PINK},{PURPLE});
  box-shadow:0 0 14px rgba(236,72,153,0.45); transform-origin:left;
  animation:fl-grow 1.1s cubic-bezier(.2,.8,.2,1) both; }}
@keyframes fl-grow {{ from {{ transform:scaleX(0); }} to {{ transform:scaleX(1); }} }}

/* stepped funnel */
.fl-funnel {{ position:relative; margin-top:6px; }}
.fl-funnel-grid {{ display:grid; gap:0; }}
.fl-fstage {{ padding:0 14px 10px 14px; border-left:1px solid rgba(255,255,255,0.06); }}
.fl-fstage:first-child {{ border-left:none; padding-left:0; }}
.fl-fstage .nm {{ color:{MUTED}; font-size:13px; font-weight:500; display:flex; gap:8px; align-items:center; }}
.fl-fstage .val {{ color:#fff; font-size:30px; font-weight:700; letter-spacing:-0.03em; margin-top:4px; }}
.fl-fcap {{ color:{MUTED}; font-size:12px; padding:10px 14px 0 14px; }}
.fl-fcap:first-child {{ padding-left:0; }}
.fl-fcap b {{ color:#fff; font-weight:600; }}
.fl-funnel-plot {{ position:relative; display:flex; }}
.fl-yaxis {{ position:absolute; left:0; top:0; bottom:0; display:flex; flex-direction:column;
  justify-content:space-between; color:{DIM}; font-size:11px; pointer-events:none; z-index:2; }}
.fl-funnel svg {{ display:block; width:100%; }}
.fl-funnel svg .shape {{ transform-box:fill-box; animation:fl-rise 1.1s cubic-bezier(.2,.8,.2,1) both; transform-origin:bottom; }}
@keyframes fl-rise {{ from {{ transform:scaleY(0.05); opacity:0; }} to {{ transform:scaleY(1); opacity:1; }} }}

/* insight card */
.fl-insight-stat {{ font-size:40px; font-weight:800; letter-spacing:-0.035em; line-height:1.05;
  background:linear-gradient(90deg,#fff, {ICE}); -webkit-background-clip:text; background-clip:text;
  color:transparent; }}
.fl-insight-body {{ color:{MUTED}; font-size:13px; line-height:1.55; margin-top:8px; }}
.fl-spark {{ width:28px; height:28px; border-radius:9px; display:grid; place-items:center;
  background:linear-gradient(135deg, rgba(236,72,153,.25), rgba(168,85,247,.25));
  border:1px solid rgba(168,85,247,.35); font-size:14px; }}

/* tables */
.fl-table {{ width:100%; border-collapse:collapse; font-size:13px; }}
.fl-table th {{ color:{DIM}; font-weight:500; text-align:left; padding:10px 12px;
  border-bottom:1px solid {BORDER}; }}
.fl-table td {{ color:#fff; padding:12px; border-bottom:1px solid rgba(255,255,255,0.04); }}
.fl-table tr:last-child td {{ border-bottom:none; }}
.fl-table td.r, .fl-table th.r {{ text-align:right; }}

/* empty state */
.fl-empty {{ text-align:center; padding:72px 24px; }}
.fl-empty .ic {{ width:64px; height:64px; margin:0 auto 18px; border-radius:20px; display:grid; place-items:center;
  background:linear-gradient(135deg, rgba(34,197,94,.18), rgba(20,184,166,.18)); border:1px solid rgba(52,211,153,.3);
  font-size:28px; }}
.fl-empty h3 {{ color:#fff; font-size:22px; font-weight:700; margin:0 0 6px; }}
.fl-empty p {{ color:{MUTED}; font-size:14px; margin:0; }}

/* number animation fallback (fade-up) */
.countup {{ display:inline-block; animation:fl-fade .6s ease both; }}
@keyframes fl-fade {{ from {{ opacity:0; transform:translateY(6px); }} to {{ opacity:1; transform:none; }} }}

/* ---------- widgets ---------- */
[data-testid="stWidgetLabel"] p {{ color:{MUTED} !important; font-size:12px !important; }}
[data-baseweb="select"] > div, [data-baseweb="input"], .stDateInput input,
[data-testid="stDateInput"] > div > div {{
  background:{CARD} !important; border-color:{BORDER} !important; border-radius:14px !important;
}}
[data-baseweb="popover"] ul, [data-baseweb="menu"] {{ background:#121318 !important; }}
.stButton > button, .stDownloadButton > button, [data-testid="stPopover"] button,
[data-testid="stBaseButton-secondary"] {{
  background:rgba(255,255,255,0.04) !important; color:#fff !important;
  border:1px solid {BORDER} !important; border-radius:14px !important; font-weight:500 !important;
  transition:all .2s ease;
}}
.stButton > button:hover, .stDownloadButton > button:hover, [data-testid="stPopover"] button:hover {{
  border-color:rgba(255,255,255,0.22) !important; background:rgba(255,255,255,0.08) !important;
}}
[data-testid="stBaseButton-primary"], .stButton > button[kind="primary"] {{
  background:#fff !important; color:#0B0B0D !important; border:none !important; font-weight:600 !important;
}}
/* circular "next insight" arrow */
div[class*="st-key-next_insight"] button {{
  border-radius:50% !important; width:34px; height:34px; min-height:34px; padding:0 !important;
}}
[data-testid="stFileUploaderDropzone"] {{ background:rgba(255,255,255,0.02) !important;
  border:1px dashed rgba(255,255,255,0.15) !important; border-radius:16px !important; }}
[data-testid="stExpander"] details {{ background:{CARD}; border:1px solid {BORDER} !important; border-radius:18px; }}
.stSpinner > div {{ border-top-color:{MINT} !important; }}
[data-testid="stAlert"] {{ border-radius:16px; }}
[data-testid="stDataFrame"] {{ border-radius:16px; overflow:hidden; }}
.stPlotlyChart {{ margin-bottom:-6px; }}
[data-testid="stSegmentedControl"] button[aria-checked="true"],
[data-testid="stBaseButton-segmented_controlActive"] {{ background:#fff !important; color:#0B0B0D !important; }}

@media (max-width: 1100px) {{
  .fl-big {{ font-size:36px; }} .fl-title {{ font-size:32px; }}
  .fl-fstage .val {{ font-size:22px; }}
}}
</style>
"""


def inject_css() -> None:
    st.html(CSS)
