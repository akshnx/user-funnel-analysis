"""Metric calculations. Pure pandas, no Streamlit, so they are easy to test."""
from __future__ import annotations

import numpy as np
import pandas as pd

import config
from services.data import WEEKDAYS


def pct_change(cur: float, prev: float | None) -> float | None:
    if prev is None or prev == 0 or pd.isna(prev):
        return None
    return (cur - prev) / prev * 100


def _users(df: pd.DataFrame, event: str) -> set:
    return set(df.loc[df["event_type"] == event, "user_id"].unique())


def funnel(df: pd.DataFrame | None, engaged: bool | None = None,
           strict: bool = config.FUNNEL_STRICT) -> list[dict]:
    """Return funnel stages: [{key, stage, users, pct_prev, pct_top, drop}]."""
    engaged = config.ENGAGED_ENABLED if engaged is None else engaged
    if df is None or df.empty:
        return []
    visits = set(df["user_id"].unique())
    stages = [("visits", visits)]
    if engaged:
        views = df[df["event_type"] == "view"]
        n_prod = views.groupby("user_id")["product_id"].nunique()
        stages.append(("engaged", set(n_prod[n_prod >= config.ENGAGED_MIN_DISTINCT_PRODUCTS].index)))
    stages += [("cart", _users(df, "cart")), ("purchase", _users(df, "purchase"))]

    out, prev_set, top = [], None, len(visits)
    for key, users in stages:
        if strict and prev_set is not None:
            users = users & prev_set
        n = len(users)
        prev_n = len(prev_set) if prev_set is not None else n
        out.append({
            "key": key,
            "stage": config.STAGE_LABELS[key],
            "users": n,
            "pct_prev": (n / prev_n * 100) if prev_n else 0.0,
            "pct_top": (n / top * 100) if top else 0.0,
            "drop": prev_n - n,
        })
        prev_set = users
    return out


def purchases(df: pd.DataFrame | None) -> pd.DataFrame:
    if df is None:
        return pd.DataFrame(columns=["price"])
    return df[df["event_type"] == "purchase"]


def revenue(df: pd.DataFrame | None) -> float:
    return float(purchases(df)["price"].sum())


def top_categories(df: pd.DataFrame | None, n: int = 3) -> pd.Series:
    p = purchases(df)
    if p.empty:
        return pd.Series(dtype=float)
    return p.groupby("category", observed=True)["price"].sum().sort_values(ascending=False).head(n)


def unique_users(df: pd.DataFrame | None) -> int:
    return 0 if df is None else int(df["user_id"].nunique())


def daily_unique(df: pd.DataFrame | None, rng=None) -> pd.Series:
    if df is None:
        return pd.Series(dtype=float)
    s = df.groupby("date")["user_id"].nunique()
    if rng:
        s = s.reindex(pd.date_range(rng[0], rng[1], freq="D"), fill_value=0)
    return s


def purchases_by_weekday(df: pd.DataFrame | None) -> pd.Series:
    p = purchases(df)
    s = p.groupby("weekday").size().reindex(range(7), fill_value=0)
    s.index = WEEKDAYS
    return s


def aov(df: pd.DataFrame | None) -> float:
    p = purchases(df)
    if p.empty:
        return 0.0
    orders = p.groupby("user_session")["price"].sum() if p["user_session"].notna().any() else p["price"]
    return float(orders.mean())


def stage_counts_by(df: pd.DataFrame, by: str) -> pd.DataFrame:
    """Unique users per event type for each value of `by` (e.g. category)."""
    g = (df[df["event_type"].isin(["view", "cart", "purchase"])]
         .groupby([by, "event_type"], observed=True)["user_id"].nunique()
         .unstack(fill_value=0))
    for c in ["view", "cart", "purchase"]:
        if c not in g:
            g[c] = 0
    g = g[["view", "cart", "purchase"]]
    g["conversion"] = np.where(g["view"] > 0, g["purchase"] / g["view"] * 100, 0)
    g["revenue"] = purchases(df).groupby(by, observed=True)["price"].sum().reindex(g.index).fillna(0)
    return g.sort_values("view", ascending=False)


def heatmap(df: pd.DataFrame, event: str | None = None) -> pd.DataFrame:
    d = df if event in (None, "all") else df[df["event_type"] == event]
    m = d.groupby(["weekday", "hour"]).size().unstack(fill_value=0)
    m = m.reindex(index=range(7), columns=range(24), fill_value=0)
    m.index = WEEKDAYS
    return m


def time_to_purchase(df: pd.DataFrame) -> pd.Series:
    """Minutes from first view to purchase within the same session."""
    d = df[df["event_type"].isin(["view", "purchase"]) & df["user_session"].notna()]
    first_view = d[d["event_type"] == "view"].groupby("user_session")["event_time"].min()
    first_buy = d[d["event_type"] == "purchase"].groupby("user_session")["event_time"].min()
    delta = (first_buy - first_view.reindex(first_buy.index)).dropna().dt.total_seconds() / 60
    return delta[delta >= 0]


def session_lengths(df: pd.DataFrame) -> pd.DataFrame:
    """Per-session duration (min), events and whether it converted."""
    d = df[df["user_session"].notna()].assign(_buy=lambda x: x["event_type"] == "purchase")
    g = d.groupby("user_session").agg(start=("event_time", "min"), end=("event_time", "max"),
                                      events=("event_time", "size"), bought=("_buy", "max"))
    g["minutes"] = (g["end"] - g["start"]).dt.total_seconds() / 60
    g["outcome"] = np.where(g["bought"], "Purchased", "No purchase")
    return g
