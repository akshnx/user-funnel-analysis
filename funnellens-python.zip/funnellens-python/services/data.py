"""Loading, cleaning and filtering of REES46-style event data.

Expected columns (REES46 "eCommerce behavior data from multi category store"):
event_time, event_type, product_id, category_id, category_code, brand,
price, user_id, user_session
"""
from __future__ import annotations

import zlib
from dataclasses import dataclass, field
from datetime import date, timedelta

import numpy as np
import pandas as pd

import config

WEEKDAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]


class DataError(ValueError):
    """Raised with a friendly, user-facing message."""


# ---------------------------------------------------------------------------
# Sample data
# ---------------------------------------------------------------------------
_CATALOGUE = {
    # top-level: (weight, [(category_code, (price_lo, price_hi))], brands)
    "electronics": (0.30, [("electronics.smartphone", (120, 1100)),
                           ("electronics.audio.headphone", (15, 350)),
                           ("electronics.video.tv", (180, 1500)),
                           ("electronics.clocks", (40, 600))],
                    ["samsung", "apple", "xiaomi", "huawei", "sony", "lg"]),
    "appliances": (0.20, [("appliances.kitchen.refrigerators", (250, 1400)),
                          ("appliances.kitchen.washer", (200, 900)),
                          ("appliances.environment.vacuum", (60, 500))],
                   ["bosch", "lg", "samsung", "indesit", "philips"]),
    "computers": (0.14, [("computers.notebook", (300, 2200)),
                         ("computers.desktop", (350, 2000)),
                         ("computers.peripherals.mouse", (8, 120))],
                  ["lenovo", "asus", "hp", "acer", "apple", "logitech"]),
    "apparel": (0.12, [("apparel.shoes", (25, 220)),
                       ("apparel.costume", (15, 140))],
                ["nike", "adidas", "puma", "reebok"]),
    "furniture": (0.08, [("furniture.living_room.sofa", (150, 1200)),
                         ("furniture.bedroom.bed", (120, 900))],
                  ["ikea", "brw", "sonata"]),
    "kids": (0.07, [("kids.toys", (8, 120)), ("kids.carriage", (90, 600))],
             ["lego", "chicco", "hasbro"]),
    "sport": (0.05, [("sport.bicycle", (150, 1200)), ("sport.trainer", (40, 600))],
              ["stels", "forward", "torneo"]),
    "auto": (0.04, [("auto.accessories.player", (30, 300))],
             ["pioneer", "kenwood", "jvc"]),
}


def make_sample_data(seed: int = config.SAMPLE_SEED) -> pd.DataFrame:
    """Generate a realistic, REES46-shaped event log (fully synthetic)."""
    rng = np.random.default_rng(seed)

    # --- product catalogue ---------------------------------------------------
    prod_rows = []
    pid = 1_000_000
    for top, (_, codes, brands) in _CATALOGUE.items():
        for code, (lo, hi) in codes:
            cat_id = 2_053_013_550_000_000_000 + zlib.crc32(code.encode()) % 10_000_000
            for _ in range(60):
                pid += 1
                price = float(np.round(np.exp(rng.uniform(np.log(lo), np.log(hi))), 2))
                prod_rows.append((pid, cat_id, code, rng.choice(brands), price, top))
    products = pd.DataFrame(prod_rows, columns=["product_id", "category_id", "category_code",
                                                "brand", "price", "top"])
    by_top = {t: g.index.to_numpy() for t, g in products.groupby("top")}
    tops = list(_CATALOGUE)
    top_w = np.array([_CATALOGUE[t][0] for t in tops])
    top_w = top_w / top_w.sum()

    # --- sessions ------------------------------------------------------------
    n = config.SAMPLE_SESSIONS
    days = config.SAMPLE_DAYS
    t = np.arange(days)
    start = pd.Timestamp(config.SAMPLE_START)
    weekday = (start.dayofweek + t) % 7
    wd_factor = np.array([1.00, 0.95, 0.97, 1.02, 1.12, 1.25, 1.18])[weekday]
    day_w = (1 + 0.45 * t / days) * wd_factor * rng.uniform(0.92, 1.08, days)
    day_w /= day_w.sum()

    user_w = rng.pareto(1.6, config.SAMPLE_USERS) + 1
    user_w /= user_w.sum()
    s_user = rng.choice(config.SAMPLE_USERS, n, p=user_w) + 512_000_000
    s_day = rng.choice(days, n, p=day_w)
    hour_w = np.array([1, .6, .4, .3, .3, .4, .8, 1.5, 2.4, 3.0, 3.3, 3.4, 3.5, 3.4, 3.3,
                       3.3, 3.5, 3.8, 4.2, 4.6, 4.8, 4.2, 3.0, 1.8])
    s_hour = rng.choice(24, n, p=hour_w / hour_w.sum())
    s_start = (start + pd.to_timedelta(s_day, "D") + pd.to_timedelta(s_hour, "h")
               + pd.to_timedelta(rng.integers(0, 3600, n), "s"))
    s_top = rng.choice(len(tops), n, p=top_w)
    s_views = rng.geometric(0.42, n)
    s_id = np.array([f"{x:032x}" for x in rng.integers(0, 2**62, n)])

    # --- views -----------------------------------------------------------------
    v_sess = np.repeat(np.arange(n), s_views)
    v_order = np.concatenate([np.arange(k) for k in s_views])
    v_prod = np.empty(len(v_sess), dtype=int)
    for i, top in enumerate(tops):
        mask = s_top[v_sess] == i
        v_prod[mask] = rng.choice(by_top[top], mask.sum())
    gaps = rng.exponential(55, len(v_sess)).astype(int)
    v_offset = pd.Series(gaps).groupby(v_sess).cumsum().to_numpy() - gaps + v_order
    views = pd.DataFrame({"sess": v_sess, "prod_idx": v_prod,
                          "event_time": s_start[v_sess] + pd.to_timedelta(v_offset, "s"),
                          "event_type": "view"})

    # --- cart & purchase --------------------------------------------------------
    last = views.groupby("sess").tail(1)
    p_cart = np.clip(0.035 + 0.03 * (s_views[last["sess"]] - 1), 0, 0.32)
    carts = last[rng.random(len(last)) < p_cart].copy()
    carts["event_type"] = "cart"
    carts["event_time"] += pd.to_timedelta(rng.integers(5, 240, len(carts)), "s")
    abandon = rng.random(len(carts)) < 0.08
    removes = carts[abandon].copy()
    removes["event_type"] = "remove_from_cart"
    removes["event_time"] += pd.to_timedelta(rng.integers(10, 600, len(removes)), "s")
    buys = carts[~abandon & (rng.random(len(carts)) < 0.47)].copy()
    buys["event_type"] = "purchase"
    buys["event_time"] += pd.to_timedelta(rng.gamma(2.0, 240, len(buys)).astype(int) + 20, "s")

    ev = pd.concat([views, carts, removes, buys], ignore_index=True)
    p = products.iloc[ev["prod_idx"].to_numpy()].reset_index(drop=True)
    df = pd.DataFrame({
        "event_time": ev["event_time"].dt.strftime("%Y-%m-%d %H:%M:%S UTC"),
        "event_type": ev["event_type"],
        "product_id": p["product_id"],
        "category_id": p["category_id"],
        "category_code": p["category_code"],
        "brand": p["brand"],
        "price": p["price"],
        "user_id": s_user[ev["sess"].to_numpy()],
        "user_session": s_id[ev["sess"].to_numpy()],
    })
    # sprinkle a little real-world mess so the cleaning summary has something to show
    idx = rng.choice(len(df), 300, replace=False)
    df.loc[idx[:150], "category_code"] = np.nan
    df.loc[idx[150:], "brand"] = np.nan
    df = pd.concat([df, df.sample(120, random_state=seed)], ignore_index=True)
    return df.sort_values("event_time", ignore_index=True)


# ---------------------------------------------------------------------------
# Loading & cleaning
# ---------------------------------------------------------------------------
def read_csv(file) -> pd.DataFrame:
    """Read an uploaded CSV, only keeping the columns we know about."""
    wanted = set(config.REQUIRED_COLUMNS + config.OPTIONAL_COLUMNS)
    try:
        df = pd.read_csv(file, usecols=lambda c: c.strip().lower() in wanted,
                         nrows=config.MAX_UPLOAD_ROWS, low_memory=False)
    except pd.errors.EmptyDataError:
        raise DataError("The file is empty.")
    except UnicodeDecodeError:
        raise DataError("Couldn't read the file. Please upload a UTF-8 encoded CSV.")
    except Exception as exc:  # noqa: BLE001
        raise DataError(f"Couldn't parse the CSV ({exc.__class__.__name__}). "
                        "Is it a comma-separated file?")
    df.columns = [c.strip().lower() for c in df.columns]
    return df


def clean(raw: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Validate and clean raw events. Returns (clean_df, summary)."""
    missing = [c for c in config.REQUIRED_COLUMNS if c not in raw.columns]
    if missing:
        raise DataError("Missing required column(s): " + ", ".join(missing)
                        + ". Expected REES46 columns: "
                        + ", ".join(config.REQUIRED_COLUMNS + config.OPTIONAL_COLUMNS))

    s = {"rows_in": len(raw), "columns": list(raw.columns)}
    df = raw.copy()

    for col in config.OPTIONAL_COLUMNS:
        if col not in df.columns:
            df[col] = np.nan

    n0 = len(df)
    df = df.drop_duplicates()
    s["duplicates"] = n0 - len(df)

    ts = df["event_time"].astype(str).str.replace(" UTC", "", regex=False)
    parsed = pd.to_datetime(ts, format="%Y-%m-%d %H:%M:%S", errors="coerce")
    if parsed.isna().mean() > 0.5:  # not the REES46 format: let pandas infer
        parsed = pd.to_datetime(ts, errors="coerce", format="mixed")
    df["event_time"] = parsed
    df["event_type"] = df["event_type"].astype(str).str.strip().str.lower()
    df["user_id"] = pd.to_numeric(df["user_id"], errors="coerce")

    n0 = len(df)
    df = df.dropna(subset=["event_time", "user_id", "product_id"])
    s["missing_required"] = n0 - len(df)

    n0 = len(df)
    df = df[df["event_type"].isin(config.VALID_EVENT_TYPES)]
    s["invalid_event_types"] = n0 - len(df)

    df["price"] = pd.to_numeric(df["price"], errors="coerce")
    n0 = len(df)
    df = df[~(df["price"] < 0)]
    s["negative_prices"] = n0 - len(df)
    s["missing_price"] = int(df["price"].isna().sum())
    df["price"] = df["price"].fillna(0.0)

    s["missing_category"] = int(df["category_code"].isna().sum())
    df["category_code"] = df["category_code"].fillna("unknown").astype(str)
    s["missing_brand"] = int(df["brand"].isna().sum())
    df["brand"] = df["brand"].fillna("unknown").astype(str).str.lower()

    if df.empty:
        raise DataError("No valid rows left after cleaning. Check the event_type and "
                        "event_time columns.")

    df["user_id"] = df["user_id"].astype("int64")
    df["category"] = df["category_code"].str.split(".").str[0].astype("category")
    df["event_type"] = df["event_type"].astype("category")
    df["brand"] = df["brand"].astype("category")
    df["date"] = df["event_time"].dt.normalize()
    df["hour"] = df["event_time"].dt.hour.astype("int8")
    df["weekday"] = df["event_time"].dt.dayofweek.astype("int8")
    df = df.sort_values("event_time", ignore_index=True)

    s.update(rows_out=len(df), users=int(df["user_id"].nunique()),
             sessions=int(df["user_session"].nunique()),
             products=int(df["product_id"].nunique()),
             date_min=df["event_time"].min(), date_max=df["event_time"].max(),
             event_counts=df["event_type"].value_counts().to_dict())
    return df, s


# ---------------------------------------------------------------------------
# Filtering
# ---------------------------------------------------------------------------
@dataclass
class FilterContext:
    df_all: pd.DataFrame | None = None
    cur: pd.DataFrame | None = None
    prev: pd.DataFrame | None = None
    cur_range: tuple[date, date] | None = None
    prev_range: tuple[date, date] | None = None
    category: str = config.ALL_CATEGORIES
    preset: str = config.DEFAULT_PRESET
    extra: dict = field(default_factory=dict)

    @property
    def has_data(self) -> bool:
        return self.df_all is not None and not self.df_all.empty

    @property
    def has_prev(self) -> bool:
        return self.prev is not None and not self.prev.empty

    @property
    def period_label(self) -> str:
        if not self.cur_range:
            return ""
        a, b = self.cur_range
        return f"{a:%d %b} – {b:%d %b %Y}"


def resolve_period(dmin: date, dmax: date, preset: str,
                   custom: tuple[date, date] | None = None):
    """Return (current_range, previous_range) as inclusive date tuples."""
    if preset == "Last 7 days":
        cur = (max(dmin, dmax - timedelta(days=6)), dmax)
    elif preset == "Last 30 days":
        cur = (max(dmin, dmax - timedelta(days=29)), dmax)
    elif preset == "Custom" and custom and len(custom) == 2:
        cur = (max(dmin, custom[0]), min(dmax, custom[1]))
    else:  # All data
        return (dmin, dmax), None
    length = (cur[1] - cur[0]).days + 1
    prev = (cur[0] - timedelta(days=length), cur[0] - timedelta(days=1))
    if prev[1] < dmin:
        return cur, None
    return cur, prev


def slice_df(df: pd.DataFrame, rng: tuple[date, date] | None, category: str) -> pd.DataFrame | None:
    if rng is None:
        return None
    a, b = pd.Timestamp(rng[0]), pd.Timestamp(rng[1])
    out = df[(df["date"] >= a) & (df["date"] <= b)]
    if category and category != config.ALL_CATEGORIES:
        out = out[out["category"] == category]
    return out
