"""Automated insights (rule-based).

No external AI / LLM is used. Each rule below looks at the filtered data,
checks a simple condition and, if it fires, produces a short plain-English
insight with a headline stat and a severity tag.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass

import pandas as pd

import config
from services import metrics as m
from services.data import WEEKDAYS

HIGH, MEDIUM, OPPORTUNITY = "High", "Medium", "Opportunity"
_SEVERITY_ORDER = {HIGH: 0, MEDIUM: 1, OPPORTUNITY: 2}


@dataclass
class Insight:
    headline: str      # big stat, e.g. "+35.2%"
    label: str         # what the stat is, e.g. "Unique visits"
    body: str          # 1-3 sentences of explanation
    severity: str      # High / Medium / Opportunity
    rule: str          # rule id, handy for debugging / the report

    def to_dict(self) -> dict:
        return asdict(self)


def _fmt_money(x: float) -> str:
    return f"${x:,.0f}"


def generate(cur: pd.DataFrame | None, prev: pd.DataFrame | None,
             engaged: bool | None = None) -> list[Insight]:
    if cur is None or cur.empty:
        return []
    out: list[Insight] = []
    f = m.funnel(cur, engaged)
    stage = {s["key"]: s for s in f}
    visits = stage["visits"]["users"]

    # 1. Traffic trend vs previous period
    if prev is not None and not prev.empty:
        d = m.pct_change(m.unique_users(cur), m.unique_users(prev))
        if d is not None and abs(d) >= 3:
            up = d > 0
            out.append(Insight(
                f"{d:+.1f}%", "Unique visits",
                f"{m.unique_users(cur):,} unique visitors this period vs "
                f"{m.unique_users(prev):,} in the previous one. "
                + ("Traffic is growing. Make sure the funnel keeps up." if up
                   else "Traffic is falling. Check campaigns and acquisition channels."),
                MEDIUM if up else HIGH, "traffic_trend"))

        # 2. Revenue trend
        r_cur, r_prev = m.revenue(cur), m.revenue(prev)
        d = m.pct_change(r_cur, r_prev)
        if d is not None and abs(d) >= 5:
            out.append(Insight(
                f"{d:+.1f}%", "Revenue",
                f"Revenue moved from {_fmt_money(r_prev)} to {_fmt_money(r_cur)}. "
                + ("Growth is outpacing the previous period." if d > 0
                   else "Look at which categories lost sales (Segmentation page)."),
                MEDIUM if d > 0 else HIGH, "revenue_trend"))

    # 3. Biggest drop-off in the funnel
    if len(f) > 1:
        worst = min(f[1:], key=lambda s: s["pct_prev"])
        i = f.index(worst)
        out.append(Insight(
            f"{100 - worst['pct_prev']:.1f}%", f"Drop-off before {worst['stage']}",
            f"The biggest leak is between {f[i - 1]['stage']} and {worst['stage']}: "
            f"{worst['drop']:,} users never move on. Improving this step has the "
            f"largest effect on purchases.",
            HIGH, "biggest_dropoff"))

    # 4. Add-to-cart rate
    if visits:
        rate = stage["cart"]["users"] / visits * 100
        out.append(Insight(
            f"{rate:.1f}%", "of visitors add to cart",
            f"{stage['cart']['users']:,} of {visits:,} visitors added something to their cart. "
            + ("That's low for e-commerce (typical 5–10%). Clearer pricing, reviews and "
               "delivery info on product pages can help." if rate < 5
               else "That's a healthy add-to-cart rate."),
            HIGH if rate < 5 else OPPORTUNITY, "add_to_cart_rate"))

    # 5. Cart abandonment
    carts, buys = stage["cart"]["users"], stage["purchase"]["users"]
    if carts:
        ab = (1 - buys / carts) * 100
        if ab >= 40:
            out.append(Insight(
                f"{ab:.0f}%", "cart abandonment",
                f"{carts - buys:,} users added to cart but didn't buy. Reminder emails, "
                "guest checkout and visible shipping costs are the usual fixes.",
                HIGH if ab >= 60 else MEDIUM, "cart_abandonment"))

    # 6. Revenue concentration in one category
    tops = m.top_categories(cur, 5)
    total = m.revenue(cur)
    if total and not tops.empty:
        share = tops.iloc[0] / total * 100
        if share >= 35:
            out.append(Insight(
                f"{share:.0f}%", f"of revenue from {tops.index[0]}",
                f"{str(tops.index[0]).title()} brings in {_fmt_money(tops.iloc[0])}. "
                "Heavy dependence on one category is a risk; promoting the runner-ups "
                "spreads it.", MEDIUM, "category_concentration"))

    # 7. High-traffic, low-converting category
    seg = m.stage_counts_by(cur, "category")
    seg = seg[seg["view"] >= max(50, seg["view"].sum() * 0.05)]
    if len(seg) >= 2:
        avg = seg["purchase"].sum() / max(seg["view"].sum(), 1) * 100
        low = seg.sort_values("conversion").iloc[0]
        if low["conversion"] < avg * 0.75:
            out.append(Insight(
                f"{low['conversion']:.1f}%", f"conversion in {low.name}",
                f"{str(low.name).title()} gets {int(low['view']):,} viewers but converts well "
                f"below the {avg:.1f}% average. Reviewing price and product pages here "
                "is an easy win.", OPPORTUNITY, "low_converting_category"))

    # 8. Peak day / hour
    p = m.purchases(cur)
    if len(p) >= 20:
        wd = m.purchases_by_weekday(cur)
        hr = p.groupby("hour").size()
        out.append(Insight(
            wd.idxmax(), "is the peak purchase day",
            f"{int(wd.max()):,} purchases happen on {wd.idxmax()}s; the busiest hour is "
            f"{int(hr.idxmax()):02d}:00. Schedule promotions and emails just before.",
            OPPORTUNITY, "peak_time"))

    # 9. Engaged users convert better
    if "engaged" in stage and visits and stage["engaged"]["users"]:
        eng_conv = buys / stage["engaged"]["users"] * 100 if config.FUNNEL_STRICT else None
        base_conv = buys / visits * 100
        if eng_conv and base_conv and eng_conv > base_conv * 1.5:
            out.append(Insight(
                f"{eng_conv / base_conv:.1f}×", "higher conversion when engaged",
                f"Visitors who view {config.ENGAGED_MIN_DISTINCT_PRODUCTS}+ products convert at "
                f"{eng_conv:.1f}% vs {base_conv:.1f}% overall. Recommendations and "
                "'similar items' push more people into this group.",
                OPPORTUNITY, "engagement_lift"))

    out.sort(key=lambda i: _SEVERITY_ORDER[i.severity])
    return out


def to_frame(insights: list[Insight]) -> pd.DataFrame:
    return pd.DataFrame([i.to_dict() for i in insights])


def to_markdown(insights: list[Insight], period: str) -> str:
    lines = [f"# {config.APP_NAME} – automated insights", f"_Period: {period}_",
             "_Generated by rule-based logic (no AI model)._", ""]
    for i in insights:
        lines += [f"## [{i.severity}] {i.headline} {i.label}", i.body, ""]
    return "\n".join(lines)


__all__ = ["Insight", "generate", "to_frame", "to_markdown", "WEEKDAYS"]
